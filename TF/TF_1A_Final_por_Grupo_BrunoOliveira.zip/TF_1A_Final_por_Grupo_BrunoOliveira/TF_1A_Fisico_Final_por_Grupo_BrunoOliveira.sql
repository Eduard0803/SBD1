-- --------     << TF_1A_brunooliveira >>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 02/06/2024
-- Autor(es) ..............: BRUNO OLIVEIRA, EDUARDO SILVA, CARLOS ALVES
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A_brunooliveira
--
--
-- PROJETO => 01 Base de Dados
--         => 14 Tabelas
--         => 03 Visoes
--         => 03 Perfis (role)
--         => 09 Usuarios
--
-- ULTIMAS ALTERACOES => 14/06/24 - Autor: Eduardo Silva
--                          1. Inclusao do atributo 'taxaProcessamento' na tabela METODOS_DE_PAGAMENTO
--                          2. Inclusao do atributo 'sexo' na tabela PRODUTO
--                          3. Inclusao do atributo 'sexo' na tabela CLIENTE
--                          4. Inclusao do atributo 'complemento' na tabela CLIENTE
--                          5. Inclusao do atributo 'statusVenda' na tabela VENDA
--                          6. Alteracao na ordem das tabelas PEDIDO e ITEM_PEDIDO devem ser criadas antes da tabela VENDA e ITEM_VENDA
--                          7. Criacao da view ESTOQUE
--                          8. Criacao da view PRODUTOS_VENCIDOS
--
--                    => 21/06/24 - Autor: Eduardo Silva
--                          1. Alteracao no nome do atributo 'numero' da tabela 'telefone' para 'numeroCliente'
--                          2. Alteracao no tipo do atributo 'ddd' da tabela 'telefone' de VARCHAR(2) para CHAR(2)
--                          3. Renomeando tabela 'telefone' para 'telefoneCliente'
--                          4. Inclusao do atributo 'cidade' na tabela CLIENTE
--                          5. Inclusao do atributo 'email' na tabela MARCA
--                          6. Criacao da tabela 'telefoneMarca'
--                          7. Inclusao do atributo 'idPagamentoVenda' na tabela PAGAMENTO_VENDA
--                          8. Inclusao do restricao 'PAGAMENTO_VENDA_PK' na tabela PAGAMENTO_VENDA
--                          9. Criacao da tabela 'parcela'
--
--                    => 24/06/24 - Autor: Eduardo Silva
--                          1. Criacao da view LUCRO
--
--                    => 24/06/24 - Autor: Carlos Alves
--                          1. Alteracao o tipo do atributo 'sexo' da tabela CLIENTE e PRODUTO
--                          2. Adicionando restrições na tabela CLIENTE e PRODUTO nos atribustos 'sexo' permitindo só ('M','F','U')
--                          3. Criando Tabela de SITUACAO_VENDA
--                          4. Mudando o atributo status venda para chave estrangeira de SITUACAO_VENDA
--
-- -----------------------------------

CREATE DATABASE 
    IF NOT EXISTS TF_1A_brunooliveira;
USE TF_1A_brunooliveira;

CREATE TABLE METODOS_DE_PAGAMENTO (
    idMetodoPagamento INT NOT NULL AUTO_INCREMENT,
    descricao VARCHAR(100) NOT NULL,
    taxaProcessamento DECIMAL(5, 2) NOT NULL,
    CONSTRAINT METODOS_PAGAMENTO_PK PRIMARY KEY (idMetodoPagamento)
) ENGINE = InnoDB;

CREATE TABLE CLIENTE (
    idCliente INT NOT NULL AUTO_INCREMENT,
    nomeCliente VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    rua VARCHAR(100) NOT NULL,
    bairro VARCHAR(100) NOT NULL,
    numero INT NOT NULL,
    uf CHAR(2) NOT NULL,
    sexo CHAR(1) NOT NULL,
    complemento VARCHAR(100),
    CONSTRAINT CLIENTE_PK PRIMARY KEY (idCliente),
    CONSTRAINT CLIENTE_CK CHECK (sexo IN ('M', 'F', 'U'))
) ENGINE = InnoDB;

CREATE TABLE MARCA (
    idMarca INT NOT NULL AUTO_INCREMENT,
    nomeMarca VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    CONSTRAINT MARCA_PK PRIMARY KEY (idMarca)
) ENGINE = InnoDB;

CREATE TABLE CATEGORIA (
    idCategoria INT NOT NULL AUTO_INCREMENT,
    nomeCategoria VARCHAR(100) NOT NULL,
    CONSTRAINT CATEGORIA_PK PRIMARY KEY (idCategoria)
) ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    idProduto INT NOT NULL AUTO_INCREMENT,
    idMarca INT NOT NULL,
    idCategoria INT NOT NULL,
    nomeProduto VARCHAR(100) NOT NULL,
    sexo CHAR(1) NOT NULL,
    CONSTRAINT PRODUTO_PK PRIMARY KEY (idProduto),
    CONSTRAINT PRODUTO_MARCA_FK FOREIGN KEY (idMarca) REFERENCES MARCA (idMarca)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT PRODUTO_CATEGORIA_FK FOREIGN KEY (idCategoria) REFERENCES CATEGORIA (idCategoria)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
	CONSTRAINT PRODUTO_CK CHECK (sexo IN ('M', 'F', 'U'))
) ENGINE = InnoDB;

CREATE TABLE PEDIDO (
    idPedido INT NOT NULL AUTO_INCREMENT,
    dataDaCompra DATE NOT NULL,
    CONSTRAINT PEDIDO_PK PRIMARY KEY (idPedido)
) ENGINE = InnoDB;

CREATE TABLE ITEM_PEDIDO (
    idPedido INT NOT NULL,
    idProduto INT NOT NULL,
    qtdProdutos INT NOT NULL,
    precoUnitario DECIMAL(10, 2) NOT NULL,
    dataDeValidade DATE NOT NULL,
    CONSTRAINT ITEM_PEDIDO_PEDIDO_FK FOREIGN KEY (idPedido) REFERENCES PEDIDO (idPedido)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT ITEM_PEDIDO_PRODUTO_FK FOREIGN KEY (idProduto) REFERENCES PRODUTO (idProduto)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE SITUACAO_VENDA (
    idStatus INT NOT NULL AUTO_INCREMENT,
    nomeStatus VARCHAR(100) NOT NULL,
    CONSTRAINT SITUACAO_VENDA_PK PRIMARY KEY (idStatus)
) ENGINE = InnoDB;

CREATE TABLE VENDA (
    idVenda INT NOT NULL AUTO_INCREMENT,
    idCliente INT NOT NULL,
    dataDaVenda DATE NOT NULL,
    idStatus INT  NOT NULL,
    CONSTRAINT VENDA_PK PRIMARY KEY (idVenda),
    CONSTRAINT VENDA_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
	CONSTRAINT VENDA_SITUACAO_VENDA_FK FOREIGN KEY (idStatus) REFERENCES SITUACAO_VENDA (idStatus)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE ITEM_VENDA (
    idVenda INT NOT NULL,
    idProduto INT NOT NULL,
    qtdProdutos INT NOT NULL,
    precoUnitario DECIMAL(10, 2) NOT NULL,
    precoUnitarioMedioPedido DECIMAL(10, 2) NOT NULL,
    CONSTRAINT ITEM_VENDA_VENDA_FK FOREIGN KEY (idVenda) REFERENCES VENDA (idVenda)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT ITEM_VENDA_PRODUTO_FK FOREIGN KEY (idProduto) REFERENCES PRODUTO (idProduto)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE PAGAMENTO_VENDA (
    idPagamentoVenda INT NOT NULL AUTO_INCREMENT,
    idVenda INT NOT NULL,
    idMetodoPagamento INT NOT NULL,
    CONSTRAINT PAGAMENTO_VENDA_PK PRIMARY KEY (idPagamentoVenda),
    CONSTRAINT PAGAMENTO_VENDA_VENDA_FK FOREIGN KEY (idVenda) REFERENCES VENDA (idVenda)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT PAGAMENTO_VENDA_METODOS_DE_PAGAMENTO_FK FOREIGN KEY (idMetodoPagamento) REFERENCES METODOS_DE_PAGAMENTO (idMetodoPagamento)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE parcela (
    idPagamentoVenda INT NOT NULL,
    valorParcela DECIMAL(10, 2) NOT NULL,
    dataVencimento DATE NOT NULL,
    CONSTRAINT parcela_PAGAMENTO_VENDA_FK FOREIGN KEY (idPagamentoVenda) REFERENCES PAGAMENTO_VENDA (idPagamentoVenda)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE telefoneCliente (
    idCliente INT NOT NULL,
    ddd VARCHAR(2) NOT NULL,
    numero VARCHAR(9) NOT NULL,
    CONSTRAINT telefone_idCliente_ddd_numero_UK UNIQUE (idCliente, numero, ddd),
    CONSTRAINT telefone_CLIENTE_FK FOREIGN KEY (idCliente) REFERENCES CLIENTE (idCliente)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE TABLE telefoneMarca (
    idMarca INT NOT NULL,
    ddd VARCHAR(2) NOT NULL,
    numero VARCHAR(9) NOT NULL,
    CONSTRAINT telefone_idMarca_ddd_numero_UK UNIQUE (idMarca, numero, ddd),
    CONSTRAINT telefone_MARCA_FK FOREIGN KEY (idMarca) REFERENCES MARCA (idMarca)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE = InnoDB;

CREATE VIEW ESTOQUE AS
    SELECT 
        ip.idProduto,
        p.nomeProduto,
        m.nomeMarca,
        c.nomeCategoria,
        (IFNULL(SUM(ip.qtdProdutos), 0) - IFNULL(SUM(iv.qtdProdutos), 0)) AS qtdProdutosDisponiveis
    FROM 
        ITEM_PEDIDO ip
    LEFT JOIN 
        ITEM_VENDA iv ON ip.idProduto = iv.idProduto
    JOIN
        PRODUTO p ON ip.idProduto = p.idProduto
    JOIN
        MARCA m ON p.idMarca = m.idMarca
    JOIN
        CATEGORIA c ON p.idCategoria = c.idCategoria
    WHERE 
        ip.dataDeValidade >= CURDATE()
    GROUP BY 
        ip.idProduto, ip.qtdProdutos;

CREATE VIEW PRODUTOS_VENCIDOS AS
    SELECT 
        ip.idProduto,
        p.nomeProduto,
        m.nomeMarca,
        c.nomeCategoria,
        (IFNULL(SUM(ip.qtdProdutos), 0) - IFNULL(SUM(iv.qtdProdutos), 0)) AS qtdProdutosVencidos
    FROM 
        ITEM_PEDIDO ip
    LEFT JOIN 
        ITEM_VENDA iv ON ip.idProduto = iv.idProduto
    JOIN
        PRODUTO p ON ip.idProduto = p.idProduto
    JOIN
        MARCA m ON p.idMarca = m.idMarca
    JOIN
        CATEGORIA c ON p.idCategoria = c.idCategoria
    WHERE 
        ip.dataDeValidade < CURDATE()
    GROUP BY 
        ip.idProduto, ip.qtdProdutos;

CREATE VIEW LUCRO AS
SELECT
    YEAR(v.dataDaVenda) AS ano,
    MONTH(v.dataDaVenda) AS mes,
    SUM(iv.qtdProdutos * (iv.precoUnitario - iv.precoUnitarioMedioPedido)) AS lucro
FROM
    ITEM_VENDA iv
JOIN
    VENDA v ON iv.idVenda = v.idVenda
GROUP BY
    ano, mes;
