-- -------- < aula4exer6Evolucao3 > --------
--
--                    SCRIPT DE INSERCAO (DML)
--
-- Data Criacao ...........: 01/05/2024
-- Autor(es) ..............: Eduardo Belarmino Silva
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula4exer6Evolucao3
--
-- 
--
-- ---------------------------------------------------------

USE aula4exer6Evolucao3;

-- Populando a tabela CATEGORIA
INSERT INTO CATEGORIA (categoria) VALUES 
('Sedan'), 
('SUV'), 
('Hatchback'),
('Caminhonete'),
('Esportivo'),
('Caminhão');

-- Populando a tabela TIPOINFRACAO
INSERT INTO TIPOINFRACAO (descricaoInfracao, valorInfracao) VALUES 
('Excesso de Velocidade', 150.00), 
('Estacionamento Irregular', 100.00), 
('Ultrapassagem Proibida', 200.00),
('Avanço de Sinal Vermelho', 250.00),
('Dirigir Falando ao Celular', 180.00),
('Estacionamento em Local Proibido', 120.00);

-- Populando a tabela LOCALINFRACAO
INSERT INTO LOCALINFRACAO (latitude, longitude, velocidadePermitida) VALUES 
('40.7128° N', '74.0060° W', 60), 
('34.0522° N', '118.2437° W', 50), 
('51.5074° N', '0.1278° W', 70),
('48.8566° N', '2.3522° E', 40),
('35.6895° N', '139.6917° E', 60),
('41.9028° N', '12.4964° E', 50);

-- Populando a tabela MODELO
INSERT INTO MODELO (modelo) VALUES 
('Toyota Corolla'), 
('Jeep Wrangler'), 
('Volkswagen Golf'),
('Ford Ranger'),
('Chevrolet Camaro'),
('Scania R-Series');

-- Populando a tabela UF
INSERT INTO UF (sigla, nome) VALUES 
('SP', 'São Paulo'), 
('RJ', 'Rio de Janeiro'), 
('MG', 'Minas Gerais'),
('RS', 'Rio Grande do Sul'),
('PR', 'Paraná'),
('BA', 'Bahia');

-- Populando a tabela AGENTE
INSERT INTO AGENTE (matricula, nome, dataDeContratacao, tempoDeServico) VALUES 
('123456', 'João Silva', '2020-01-15', 4), 
('789012', 'Maria Oliveira', '2018-05-20', 6), 
('345678', 'José Santos', '2017-10-10', 8),
('901234', 'Ana Costa', '2019-03-25', 5),
('567890', 'Pedro Almeida', '2016-07-15', 9),
('234567', 'Mariana Lima', '2015-11-30', 10);

-- Populando a tabela ENDERECO
INSERT INTO ENDERECO (logradouro, complemento, bairro, cidade, uf) VALUES 
('Rua A', 'Apt 101', 'Centro', 'São Paulo', 'SP'), 
('Avenida B', 'Casa 20', 'Copacabana', 'Rio de Janeiro', 'RJ'), 
('Rua C', 'Sobrado 5', 'Santo Antônio', 'Belo Horizonte', 'MG'),
('Av. D', 'Loja 15', 'Centro', 'Porto Alegre', 'RS'),
('Rua E', 'Casa 10', 'Batel', 'Curitiba', 'PR'),
('Av. F', 'Apt 202', 'Itaigara', 'Salvador', 'BA');

-- Populando a tabela PROPRIETARIO
INSERT INTO PROPRIETARIO (cpf, nome, idEndereco, sexo, dataDeNascimento) VALUES 
('12345678901', 'Ana Souza', 1, 'Feminino', '1980-03-12'), 
('98765432109', 'Carlos Oliveira', 2, 'Masculino', '1975-07-25'), 
('45678912307', 'Mariana Santos', 3, 'Feminino', '1992-11-30'),
('78901234508', 'José Pereira', 4, 'Masculino', '1985-05-18'),
('23456789012', 'Amanda Costa', 5, 'Feminino', '1978-09-20'),
('56789012345', 'Lucas Silva', 6, 'Masculino', '1987-12-05');

-- Populando a tabela VEICULO
INSERT INTO VEICULO (idProprietario, idModelo, idCategoria) VALUES 
(1, 1, 1), 
(2, 2, 2), 
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6);

-- Populando a tabela INFRACAO
INSERT INTO INFRACAO (tipoInfracao, idVeiculo, horario, localInfracao, velocidadeAferida, agenteDeTransito) VALUES 
(1, 1, '2024-05-01 08:30:00', 1, 80, '123456'), 
(2, 2, '2024-05-02 10:45:00', 2, 65, '789012'), 
(3, 3, '2024-05-03 14:20:00', 3, 90, '345678'),
(4, 4, '2024-05-04 16:55:00', 4, 70, '901234'),
(5, 5, '2024-05-05 12:10:00', 5, 75, '567890'),
(6, 6, '2024-05-06 09:20:00', 6, 85, '234567');

-- Populando a tabela TELEFONE
INSERT INTO TELEFONE (ddi, ddd, numero, idProprietario) VALUES 
(55, 11, 912345678, 1), 
(55, 21, 987654321, 2), 
(55, 31, 876543210, 3),
(55, 51, 765432109, 4),
(55, 41, 654321098, 5),
(55, 71, 543210987, 6);
